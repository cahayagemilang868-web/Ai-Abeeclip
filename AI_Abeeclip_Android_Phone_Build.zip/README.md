# AI Abeeclip — Android prototype

Starter project for the Android hybrid video editor discussed in chat.

## Included in this prototype
- Android app shell built with Kotlin + Jetpack Compose
- Video picker using Android's document picker
- Four navigation areas: Edit, AI Golden Moment, Subtitle, Export
- UI flow and status feedback for the intended workflow

## Important: prototype status
This is a UI and project scaffold, **not yet a production video editor**. The AI Golden Moment button currently creates a placeholder status; it does not run an AI model. Automatic transcription, subtitle timing/editing, timeline trimming, rendering, and export still need implementation and device testing.

## Build
1. Install Android Studio (Ladybug or newer) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Run the `app` configuration on an Android 8.0+ device/emulator.

## Planned implementation stages
1. Playback and timeline using AndroidX Media3.
2. Real trimming/concatenation and export via Media3 Transformer.
3. Speech-to-text integration and editable SRT subtitle track.
4. Golden-moment scoring: scene changes, audio peaks, speech/emotion cues, and semantic ranking.
5. Presets for Shorts/Reels/TikTok and 16:9 long-form video.

## Long videos
The design is not limited to one-hour videos. Practical limits depend on phone RAM, storage, codec, resolution, and the analysis strategy. Long videos should be processed in chunks rather than loaded fully into memory.


## Build an APK using only an Android phone (GitHub cloud build)

This project includes `.github/workflows/build-apk.yml`. GitHub Actions builds the debug APK on GitHub's cloud servers, so a computer is not required.

1. In your phone browser, sign in to GitHub and create a **new public or private repository** (for example `ai-abeeclip`).
2. Open the new repository, choose **Add file → Upload files**, and upload the *contents* of this ZIP (including the hidden `.github` folder). If the mobile page cannot upload a folder/hidden folder, use GitHub's web upload in desktop-site mode or the GitHub mobile app/browser that supports it.
3. Commit the uploaded files to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build AI Abeeclip APK** and tap **Run workflow** if it did not start automatically.
5. Wait for the workflow to finish successfully. Open the completed run, scroll to **Artifacts**, and download `AI-Abeeclip-debug-APK`.
6. Extract the downloaded ZIP on your phone. Tap `app-debug.apk` to install it. If Android asks, allow your browser or file manager to install unknown apps, then retry installation.

The APK is a debug/test build. Android may show a warning because it is not distributed through Play Store. Only install the APK you built from your own repository.

**Limitations:** This creates an installable prototype shell. AI Golden Moment, automatic speech-to-text subtitles, full timeline editing, and video export are not implemented yet; their buttons are currently placeholders. The app is not yet a finished production editor.
