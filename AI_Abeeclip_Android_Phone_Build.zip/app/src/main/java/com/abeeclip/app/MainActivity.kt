package com.abeeclip.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101426)
private val Panel = Color(0xFF1B2340)
private val Accent = Color(0xFF8B7CFF)
private val Mint = Color(0xFF63E6BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AbeeclipApp() }
    }
}

@Composable
fun AbeeclipApp() {
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("Belum ada video") }
    var status by remember { mutableStateOf("Pilih video untuk mulai mengedit") }
    var tab by remember { mutableStateOf("Edit") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedVideo = uri
            videoName = uri.lastPathSegment ?: "Video dipilih"
            status = "Video siap dianalisis"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Accent,
        secondary = Mint, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Edit", "Momen AI", "Subtitle", "Ekspor").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                when(item) {
                                    "Momen AI" -> Icons.Default.AutoAwesome
                                    "Subtitle" -> Icons.Default.Subtitles
                                    "Ekspor" -> Icons.Default.FileUpload
                                    else -> Icons.Default.ContentCut
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item) }
                    )
                }
            }
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MovieEdit, null, tint = Accent, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text("AI ABEECLIP", fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("CLIP • CAPTION • SHARE", color = Mint, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Surface(color = Panel, shape = RoundedCornerShape(50)) {
                            Text("BETA 0.1", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                color = Mint, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("WORKSPACE VIDEO", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Box(
                                Modifier.fillMaxWidth().height(180.dp)
                                    .background(Color(0xFF0C1020), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.VideoLibrary, null, tint = Accent, modifier = Modifier.size(42.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text(videoName, fontWeight = FontWeight.SemiBold)
                                    Text(if (selectedVideo == null) "MP4 • MOV • WEBM" else "Video berhasil dimuat",
                                        color = Color.LightGray, fontSize = 12.sp)
                                }
                            }
                            Button(onClick = { picker.launch(arrayOf("video/*")) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Pilih video dari perangkat")
                            }
                            Text(status, color = Mint, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Text("FITUR UTAMA", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FeatureCard("AI Golden Moment", "Deteksi bagian paling menarik", Icons.Default.AutoAwesome, Modifier.weight(1f))
                        FeatureCard("Auto Subtitle", "Transkrip & teks otomatis", Icons.Default.Subtitles, Modifier.weight(1f))
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(when(tab) {
                                "Momen AI" -> "AI GOLDEN MOMENT"
                                "Subtitle" -> "AUTO SUBTITLE"
                                "Ekspor" -> "PENGATURAN EKSPOR"
                                else -> "EDITOR HYBRID"
                            }, fontWeight = FontWeight.Bold)
                            when(tab) {
                                "Momen AI" -> {
                                    Text("Analisis video untuk menemukan hook, perubahan adegan, ekspresi, dan puncak audio.", color = Color.LightGray, fontSize = 13.sp)
                                    Button(onClick = { status = if (selectedVideo == null) "Pilih video terlebih dahulu" else "Antrean analisis dibuat — mesin AI perlu dihubungkan" },
                                        modifier = Modifier.fillMaxWidth()) { Text("Cari Golden Moment") }
                                }
                                "Subtitle" -> {
                                    Text("Buat subtitle otomatis, lalu edit teks dan waktunya sebelum ekspor.", color = Color.LightGray, fontSize = 13.sp)
                                    OutlinedButton(onClick = { status = "Modul transkripsi akan memerlukan izin mikrofon/audio dan engine speech-to-text" },
                                        modifier = Modifier.fillMaxWidth()) { Text("Siapkan subtitle otomatis") }
                                }
                                "Ekspor" -> {
                                    Text("Format target: MP4 • Rasio: 9:16, 16:9, 1:1 • Kualitas: 720p / 1080p", color = Color.LightGray, fontSize = 13.sp)
                                    Button(onClick = { status = "Pilih klip dan selesaikan proses edit sebelum ekspor" },
                                        modifier = Modifier.fillMaxWidth()) { Text("Ekspor video") }
                                }
                                else -> {
                                    Text("Mode hybrid: pemotongan manual dengan bantuan rekomendasi AI.", color = Color.LightGray, fontSize = 13.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        AssistChip(onClick = { status = "Fitur potong: pilih video terlebih dahulu" }, label = { Text("Potong") }, leadingIcon = { Icon(Icons.Default.ContentCut, null) })
                                        AssistChip(onClick = { status = "Fitur gabung: pilih minimal dua klip" }, label = { Text("Gabung") }, leadingIcon = { Icon(Icons.Default.Merge, null) })
                                        AssistChip(onClick = { status = "Filter dan teks akan tersedia pada tahap editor" }, label = { Text("Teks & efek") })
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    Text("ALUR KERJA", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("1. Impor video  →  2. Temukan momen terbaik  →  3. Edit klip & subtitle  →  4. Ekspor",
                        color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = Mint, modifier = Modifier.size(24.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(detail, color = Color.LightGray, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}
